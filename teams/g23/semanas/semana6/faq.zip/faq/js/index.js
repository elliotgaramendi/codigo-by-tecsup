'use strict';

import FAQ from './modules/faq.js';

document.addEventListener('DOMContentLoaded', () => {
  FAQ();
});